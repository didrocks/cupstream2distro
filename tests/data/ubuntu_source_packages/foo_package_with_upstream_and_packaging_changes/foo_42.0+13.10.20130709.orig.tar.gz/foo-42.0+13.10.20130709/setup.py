Fake setup

Change here
Python is my passion
